# se inicializan algunas variables
# tolerancia, iterador, x_inf, x_sup, amplitud

while(condicion){
	x_med   # se calcula el punto medio del intervalo
	fx_med  # se evalua f(x_med)	
	# se actualizan los limites
	if (fx_inf*fx_med <0) {
		x_sup<-x_med
	} else {
		x_inf<-x_med
	}
	# por ultimo se actualiza la condicion y se incrementa el iterador
}

tol<-1e-5; iter<-1; x_inf<-0.1; x_sup<-5; amplitud<-Inf; maxiter<-1000
fx_sup <- log(x_sup) - exp(-x_sup)
fx_inf <- log(x_inf) - exp(-x_inf)
while(amplitud>tol & iter<maxiter){
	x_med <- (x_sup + x_inf)/2
	fx_med <- log(x_med) - exp(-x_med)	
	if (fx_inf*fx_med < 0) {
		x_sup<-x_med
		fx_sup<-fx_med
	} else {
		x_inf  <- x_med
		fx_inf <- fx_med
	}
	amplitud <- x_sup - x_inf
	iter <- iter + 1
}

biseccion<-function(x_inf,x_sup,tol=1e-5,maxiter=1000){
	amplitud<-Inf
	fx_sup <- log(x_sup) - exp(-x_sup)
	fx_inf <- log(x_inf) - exp(-x_inf)
	iter<-1
	while(amplitud>tol & iter<maxiter){
		x_med <- (x_sup + x_inf)/2
		fx_med <- log(x_med) - exp(-x_med)	
		if (fx_inf*fx_med < 0) {
			x_sup<-x_med ; fx_sup<-fx_med
		} else {
			x_inf  <- x_med ; fx_inf <- fx_med
		}
		amplitud <- x_sup - x_inf
		iter <- iter + 1
        #        print(iter)
	}
	result<-list(raiz=x_med,fraiz=fx_med,iteraciones=iter,precision=amplitud)	
	return(result)
}

biseccion<-function(FUN,x_inf,x_sup,tol=1e-5,maxiter=1000){
	amplitud<-Inf
	fx_sup <- FUN(x_sup)
	fx_inf <- FUN(x_inf)
	iter<-1
	while(amplitud>tol & iter<maxiter){
		x_med <- (x_sup + x_inf)/2
		fx_med <- FUN(x_med)
		if (fx_inf*fx_med < 0) {
			x_sup<-x_med ; fx_sup<-fx_med
		} else {
			x_inf  <- x_med ; fx_inf <- fx_med
		}
		amplitud <- x_sup - x_inf
		iter <- iter + 1
	}
	salida<-list(raiz=x_med, f_raiz=fx_med, iter=iter)
	return(salida)
}



