# se inicializan algunas variables
# tolerancia, iterador, x_inf, x_sup, amplitud

while(condicion){
	x_med   # se calcula el punto medio del intervalo
	fx_med  # se evalua f(x_med)	
	# se actualizan los limites
	if (fx_inf*fx_med <0) {
		x_sup<-x_med
	} else {
		x_inf<-x_med
	}
	# por ultimo se actualiza la condicion y se incrementa el iterador
}
# Vamos a graficar la función
abcisas<-seq(0,5,0.01)
ordenadas<-(log(abcisas)-exp(-abcisas))

plot(abcisas,ordenadas,type="l")
ftn0<-function(x) log(x)-exp(-x)

plot(abcisas,ftn0(abcisas),type="l")
abline(h=0,col=2)

tol<-1e-5; iter<-1; x_inf<-0.1; x_sup<-5; amplitud<-Inf; maxiter<-1000
fx_sup <- log(x_sup) - exp(-x_sup)
fx_inf <- log(x_inf) - exp(-x_inf)

while(amplitud>tol & iter<maxiter){
	x_med <- (x_sup + x_inf)/2
	fx_med <- log(x_med) - exp(-x_med)	
	if (fx_inf*fx_med < 0) {
		x_sup<-x_med
		fx_sup<-fx_med
	} else {
		x_inf  <- x_med
		fx_inf <- fx_med
	}
	amplitud <- x_sup - x_inf
	iter <- iter + 1
}
x_med
abline(v=x_med,col="blue")


#version 1 de la función
biseccion<-function(x_inf,x_sup,tol=1e-5,maxiter=1000){
	amplitud<-Inf
	fx_sup <- log(x_sup) - exp(-x_sup)
	fx_inf <- log(x_inf) - exp(-x_inf)
	iter<-1
	while(amplitud>tol & iter<maxiter){
		x_med <- (x_sup + x_inf)/2
		fx_med <- log(x_med) - exp(-x_med)	
		if (fx_inf*fx_med < 0) {
			x_sup<-x_med ; fx_sup<-fx_med
		} else {
			x_inf  <- x_med ; fx_inf <- fx_med
		}
		amplitud <- x_sup - x_inf
		iter <- iter + 1
        #        print(iter)
	}
	result<-list(raiz=x_med,fraiz=fx_med,iteraciones=iter,precision=amplitud)	
	return(result)
}

biseccion(0.1,5,)

biseccion<-function(FUN,x_inf,x_sup,tol=1e-5,maxiter=1000){
	tiempo1<-Sys.time()
	amplitud<-Inf
	fx_sup <- FUN(x_sup)
	fx_inf <- FUN(x_inf)
	iter<-1
	while(amplitud>tol & iter<maxiter){
		x_med <- (x_sup + x_inf)/2
		fx_med <- FUN(x_med)
		if (fx_inf*fx_med < 0) {
			x_sup<-x_med ; fx_sup<-fx_med
		} else {
			x_inf  <- x_med ; fx_inf <- fx_med
		}
		amplitud <- x_sup - x_inf
		iter <- iter + 1
	}
	tiempo2<-Sys.time()
	salida<-list(raiz=x_med, f_raiz=fx_med, iter=iter,demoro=tiempo2-tiempo1)
	return(salida)
}

biseccion(ftn0,0.1,5)

ipf<-function(FUN,x0,tol=1e-5,maxiter=1000){
	x_new <- FUN(x0)
	iter<-1
	while(abs(x_new-x0) > tol & iter<maxiter){
		x0<-x_new
		x_new <- FUN(x0)
		if(is.nan(x_new)){
		stop("No puede evaluar")
		}
		iter <- iter + 1
		print(x_new)
		print(x0)
		print(iter)
		
	}
	salida<-list(pf=x_new, iter=iter)
	return(salida)
}


ipf<-function(FUN,x0,tol=1e-5,maxiter=1000,trace=TRUE){
	tiempo1<-Sys.time()
	x_new <- FUN(x0)
	iter<-1
	while(abs(x_new-x0) > tol & iter<maxiter){
		x0<-x_new
		x_new <- FUN(x0)
		iter <- iter + 1
		if (trace==TRUE) {
		cat(paste('x_',iter,sep=''),'=',x_new,'\n')}
	}
	if(iter==maxiter) {
		cat('No hubo convergencia luego de',iter,'iteraciones','\n')
	} else {
		cat('Si hubo convergencia luego de',iter,'iteraciones','\n')
	}
	tiempo2<-Sys.time()
	salida<-list(pf=x_new, iter=iter,demoro=tiempo2-tiempo1)
	return(salida)
		
}

ftn0<- function(x) return(log(x)-exp(-x))
ftn1 <- function(x) return(exp(exp(-x)))
ftn2 <- function(x) return(x-log(x)+exp(-x))
ftn3 <- function(x) return(x+log(x)-exp(-x))
ftn1(2)

ipf(ftn1,2,tol=1e-7,10000)
ipf(ftn2,2,tol=1e-5,10000)
ipf(ftn3,2,tol=1e-7,10000)
ftn0(1.3098)


# Ejemplo para calcular raiz cuadrada de 2

x<-seq(0,10,0.001)
raiz<-function(x) return(sqrt(x))
plot(x,raiz(x),type="l")
abline(v=2,col="red")

g_x<-function(x)return(x**2-2)


plot(x,g_x(x),type="l")
abline(v=2,col="red")
abline(h=0,col="green")
lines(x,raiz(x),col="blue")
biseccion(g_x,0,2)
abline(h=biseccion(g_x,0,2)$raiz,col="red")


#graficamos de vuelta en un entorno mas chico

plot(x,g_x(x),type="l",xlim =c(0,2),ylim = c(g_x(0),g_x(2)) )
abline(v=2,col="red")
abline(h=0,col="green")
abline(v=biseccion(g_x,0,2)$raiz,col="red")
lines(x,raiz(x),col="blue")

abline(h=biseccion(g_x,0,2)$raiz,col="blue")


nr <- function(FUN, FUN1, x0, tol = 1e-5, maxiter=1000,trace=TRUE){
	tiempo1<-Sys.time()
	x_new <- x0 - FUN(x0)/FUN1(x0)
	iter <- 1
	while(abs(x_new-x0) > tol & iter<maxiter){
		x0 <- x_new
		x_new <- x0 - FUN(x0)/FUN1(x0)
		iter <- iter + 1
		if (trace==TRUE) {
		cat(paste('x_',iter,sep=''),'=',x_new,'\n')}
	}
	if(iter==maxiter) {
		cat('No hubo convergencia luego de',iter,'iteraciones','\n')
	} else {
		cat('Si hubo convergencia luego de',iter,'iteraciones','\n')
	}
	tiempo2<-Sys.time()
	salida<-list(raiz = x_new, f_raiz = FUN(x_new), iter = iter,demoro=tiempo2-tiempo1)
	return(salida)
}
dftno<-function(x)return(1/x+exp(-x))
ftn0(3.22)
dftno(3.22)
nr(ftn0,dftno,3.21,trace=FALSE)
plot(abcisas,dftno(abcisas))


x0 <- x_new
x_new <- x0 - ftn0(x0)/dftno(x0)

https://www.unioviedo.es/compnum/laboratorios_py/new/03_Ec_no_lin1.html