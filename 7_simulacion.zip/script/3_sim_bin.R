sim_bin<-function(m,n,p){
  
camas<-matrix(runif(m*n),m,n)
ccamas<-camas[,1:n]<p
binomiales<-rowSums(ccamas)
return(binomiales)}



N = 1000
n <- 1000

cama1<-sim_bin(N,20,0.9)

M = 10000

v = rep(0,M)

for (i in 1:M) {
  v[i]  = mean(sim_bin(N,20,0.9))
}

mean(v)
var(v)
sd(v)
sd(v) / sqrt(M)

cama2<-sim_bin(n,20,0.7)
table(cama1+cama2)
plot(table(cama1+cama2))
plot(table(cama1+cama2>30)/(n))
plot(ecdf(cama1 +  cama2))















p<-0.6
n<-50
m<-100
matriz<-matrix(runif(n*m),nrow = m,ncol = n,byrow = TRUE)
matriz
simula<-apply(matriz>1-p, MARGIN = 1, sum)
simula
table(simula)
