# Simulación Estadística
# Rubén Fernández Casal (ruben.fcasal@udc.es), Ricardo Cao (rcao@udc.es)
# Edición: Agosto de 2022. Impresión: 2022-11-04

# https://rubenfcasal.github.io/simbook2/index.html.

remotes::install_github("rubenfcasal/simres")
