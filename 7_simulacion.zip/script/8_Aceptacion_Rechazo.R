#https://es.wikipedia.org/wiki/M%C3%A9todo_de_aceptaci%C3%B3n_y_rechazo


#aceptacion y rechazo
# program spuRs/resources/scripts/gamma.sim.r
gamma.sim <- function(lambda, m) {
  # sim a gamma(lambda, m) rv using rejection with an exp envelope
  # assumes m > 1 and lambda > 0
  f <- function(x) lambda^m*x^(m-1)*exp(-lambda*x)/gamma(m)
  h <- function(x) lambda/m*exp(-lambda/m*x)
  k <- m^m*exp(1-m)/gamma(m)
  while (TRUE) {
    X <- -log(runif(1))*m/lambda
    Y <- runif(1, 0, k*h(X))
    if (Y < f(X)) return(X)
  }
}
set.seed(1999)
n <- 10000
g <- rep(0, n)
for (i in 1:n) g[i] <- gamma.sim(1, 2)
hist(g, breaks=50, freq=F, xlab="x", ylab="pdf f(x)",
     main="densidad teorica y simulada para gamma(1, 2)")
x <- seq(0, max(g), .01)
lines(x, dgamma(x, 2, 1))


#Simulacion de BETA(alfa,beta) por aceptacion y rechazo
par(mfrow=c(1,2))
f=function(x){dbeta(x,2.7,6.3)}
M<-optimize(f, interval=c(0,1),maximum =TRUE)$objective
M

Nsim=2500
a=2.7;b=6.3

u=runif(Nsim,max=M)#uniform en intervalo (0,M)
y=runif(Nsim)#generacion a partir de g
x=y[u<dbeta(y,a,b)] #muestra aceptada
z<-u<dbeta(y,a,b)
plot(y,u,col=z*1+8)
curve(f,0,1,add=TRUE,col=4) 
abline(h=M,col=3)

#f=function(x,a,b,u){dbeta(x,a,b)*u}
M<-optimize(f=function(x)dbeta(x,2.7,6.3)/dbeta(x,2,6), interval=c(0,1),maximum =TRUE)$objective
M
Nsim=2500
a=2;b=6
u=runif(Nsim,max=M)#uniform en intervalo (0,M)
y=rbeta(Nsim,a,b)#generacion a partir de g que es Beta(a,b)
x=y[u<(dbeta(y,2.7,6.3)/(dbeta(y,a,b)))] #muestra aceptada
z<-u<(dbeta(y,2.7,6.3)/dbeta(y,a,b))
plot(y,u*dbeta(y,a,b),col=z*1+8)
curve(dbeta(x,2.7,6.3),0,1,add=TRUE,col=4) 
lines(seq(0,1,1/2499),dbeta(seq(0,1,1/2499),a,b)*u) 
