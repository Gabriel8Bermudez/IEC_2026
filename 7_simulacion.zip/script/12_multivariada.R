#Transformaciones 
y<-seq(0,1,0.01)
plot(2*y+1,y)

plot(2*y+1,y,xlim=c(0,4))
plot(2*y+1,y,xlim=c(0,4),type="l")
x<-c(seq(0,1,0.01),2*y+1,seq(3,4,0.01))
y<-c(rep(0,101),y,rep(1,101))

f<-function(x)return(2*x+1)

plot(x,y,type="l")
segments(0,0.2,f(0.2),0.2,col=2)
segments(0,0.4,f(0.4),0.4,col=3)
segments(f(0.2),0,f(0.2),0.2,col=2)
segments(f(0.4),0,f(0.4),0.4,col=3)
abline(h=0,col="grey")

g<-function(x)return(-log(1-x))
z<-seq(0,1,0.01)
plot(g(z),z,type="l",ylab="U",xlab="X")

#curve(g,0,4)
segments(0,0.15,g(0.15),0.15,col=2)
segments(0,0.2,g(0.2),0.2,col=3)
segments(g(0.15),0,g(0.15),0.15,col=2)
segments(g(0.2),0,g(0.2),0.2,col=3)
segments(0,0.85,g(0.85),0.85,col=2)
segments(0,0.9,g(0.9),0.9,col=3)
segments(g(0.85),0,g(0.85),0.85,col=2)
segments(g(0.9),0,g(0.9),0.9,col=3)

abline(h=0,col="grey")

# Como son las funciones que simulan distribuciones en R?

?rnorm

#.Random.seed Es un vector de enteros, que contiene el estado del generador de números aleatorios (RNG) con el que va generar de números aleatorios en R. Se puede guardar y restaurar, pero no debe ser alterada por el usuario.


#"Wichmann-Hill"
# The seed, .Random.seed[-1] == r[1:3] is an integer vector of length 3, where each r[i] is in 1:(p[i] - 1), where p is the length 3 vector of primes, p = (30269, 30307, 30323). The Wichmann–Hill generator has a cycle length of 6.9536e12 (= prod(p-1)/4, see Applied Statistics (1984) 33, 123 which corrects the original article).

"Marsaglia-Multicarry":
#   A multiply-with-carry RNG is used, as recommended by George Marsaglia in his post to the mailing list ‘sci.stat.math’. It has a period of more than 2^60 and has passed all tests (according to Marsaglia). The seed is two integers (all values allowed).
# 
# "Super-Duper":
#   Marsaglia's famous Super-Duper from the 70's. This is the original version which does not pass the MTUPLE test of the Diehard battery. It has a period of about 4.6*10^18 for most initial seeds. The seed is two integers (all values allowed for the first seed: the second must be odd).
  
  
 set.seed(42)
runif(2)
 RNG.state <- .Random.seed
 runif(2)
 set.seed(42)
 runif(4)
 .Random.seed <- RNG.state
 runif(2)
 
 





#En matemáticas, la factorización o descomposición de Cholesky toma su nombre del matemático André-Louis Cholesky, quien encontró que una matriz simétrica definida positiva puede ser descompuesta como el producto de una matriz triangular inferior y la traspuesta de la matriz triangular inferior. La matriz triangular inferior es el triángulo de Cholesky de la matriz original positiva definida. El resultado de Cholesky ha sido extendido a matrices con entradas complejas. Es una manera de resolver sistemas de ecuaciones matriciales y se deriva de la factorización LU con una pequeña variación.

#Cualquier matriz cuadrada A con pivotes no nulos puede ser escrita como el producto de una matriz triangular inferior L y una matriz triangular superior U; esto recibe el nombre de factorización LU. Sin embargo, si A es simétrica y definida positiva, se pueden escoger los factores tales que U es la transpuesta de L, y esto se llama la descomposición o factorización de Cholesky. Tanto la descomposición LU como la descomposición de Cholesky son usadas para resolver sistemas de ecuaciones lineales. Cuando es aplicable, la descomposición de Cholesky es dos veces más eficiente que la descomposición LU.



#El Algoritmo QR es un algoritmo usado en álgebra lineal para el cálculo de valores y vectores propios de una matriz. Se basa en la descomposición QR

(m <- matrix(c(5,1,1,3),2,2))
 ?chol
(cm <- chol(m))
t(cm) %*% cm  #-- = 'm'
?crossprod
crossprod(cm)  #-- = 'm'



# now for something positive semi-definite
x <- matrix(c(1:5, (1:5)^2), 5, 2)
x <- cbind(x, x[, 1] + 3*x[, 2])
colnames(x) <- letters[20:22]
m <- crossprod(x)
qr(m)$rank # is 2
m1<-qr(m)$qr
t(m1) %*%  m1

# chol() may fail, depending on numerical rounding:
# chol() unlike qr() does not use a tolerance.
try(chol(m))

(Q <- chol(m, pivot = TRUE))
## we can use this by
pivot <- attr(Q, "pivot")
crossprod(Q[, order(pivot)]) # recover m

## now for a non-positive-definite matrix
( m <- matrix(c(5,-5,-5,3), 2, 2) )
try(chol(m))  # fails
(Q <- chol(m, pivot = TRUE)) # warning
crossprod(Q)  # not equal to m



B<-matrix(c(4,12,-16,12,37,-43,-16,-43,98),3,3)
B
chol(B)
t(chol(B))%*%chol(B)

#Generacion de Normal multivariada con descomposición de Cholesky
#La descomposición de Cholesky se usa comúnmente en el método de Montecarlo para simular sistemas con variables múltiples correlacionadas: la matriz de correlación entre variables es descompuesta, para obtener la triangular inferior L. Aplicando ésta a un vector de ruidos simulados incorrelacionados, u produce un vector Lu con las propiedades de covarianza del sistema a ser modelado.

t<-1000
set.seed(1234)
(Sigma=cov(matrix(rnorm(20),nrow=10)))
(Sigma.cor=cor(matrix(rnorm(20),nrow=10)))

Sigma
A=t(chol(Sigma))
A
A%*%t(A)
(x=A%*%rnorm(2))
y<-matrix(0,t,2)

for (i in 1:t)
{y[i,]<-A%*%rnorm(2)}
plot(y)
cor(y)

library(MASS)  
library(RColorBrewer)
k <- 11
my.cols <- rev(brewer.pal(k, "RdYlBu"))

z34 <- kde2d(y[,1], y[,2], n=50)
contour(z34, drawlabels=TRUE, nlevels=k, col=rainbow(k), add=TRUE,lwd=2)
filled.contour(z34$x,z34$y,z34$z,nlevels=k,col = rainbow(k))


persp(z34$x,z34$y,z34$z, theta = -30, phi = 20, expand = 0.55, col = "red",shade = 0.45,scale=TRUE) 



#Simulacion de normal multivariada con libreria rmnorm mnormt

library(mnormt)


x <- seq(-2, 4, length=21)
y <- cos(2*x) + 10
z <- x + sin(3*y) 
mu <- c(1,12,2)
Sigma <- matrix(c(1,2,0,2,5,0.5,0,0.5,3), 3, 3)
f <- dmnorm(cbind(x,y,z), mu, Sigma)
f0 <- dmnorm(mu, mu, Sigma)
p1 <- pmnorm(c(2,11,3), mu, Sigma)
p2 <- pmnorm(c(2,11,3), mu, Sigma, maxpts=10000, abseps=1e-10)
p <- pmnorm(cbind(x,y,z), mu, Sigma)
#
set.seed(123)
x1 <- rmnorm(5, mu, Sigma)
set.seed(123)
x2 <- rmnorm(5, mu, sqrt=chol(Sigma)) # x1=x2
eig <- eigen(Sigma, symmetric = TRUE)
R <- t(eig$vectors %*% diag(sqrt(eig$values)))
for(i in 1:50) x <- rmnorm(5, mu, sqrt=R)
#
p <- sadmvn(lower=c(2,11,3), upper=rep(Inf,3), mu, Sigma) # upper tail
#
p0 <- pmnorm(c(2,11), mu[1:2], Sigma[1:2,1:2])
p1 <- biv.nt.prob(0, lower=rep(-Inf,2), upper=c(2, 11), mu[1:2], Sigma[1:2,1:2])
p2 <- sadmvn(lower=rep(-Inf,2), upper=c(2, 11), mu[1:2], Sigma[1:2,1:2]) 
c(p0, p1, p2, p0-p1, p0-p2)
#
p1 <- pnorm(0, 1, 3)
p2 <- pmnorm(0, 1, 3^2)

