#HIT AND MISS EN R

a <-2 ; b <-4 ; c <-0 ; d <-2
hx <- function (x) cos (2 * x) -0.3 * sin (x)+1
# area del rectangulo
A <-(b-a)*(d-c) 
# simulacion
n <- 1000
u1 <- runif(n,a,b)
u2 <- runif(n,c,d)
# proporcion
p <- mean(u2 < hx(u1))
# integral
A*p

VAR_I<-(A**2*p*(1-p))/n
