# Metodo basado en el TLC
set.seed(1234)
n<-1e6
x<-matrix(runif(12*n),n,12)

z<-apply(x,1,sum)-6

hist(z,breaks=100,freq=FALSE)
x<-seq(-5,5,0.01)
lines(x,dnorm(x),col=2,lwd=2)

mean(z>2)
1-pnorm(2)

mean(z>2.5)
1-pnorm(2.5)

mean(z>3)
1-pnorm(3)

mean(z>3.5)
1-pnorm(3.5)


# Metodo basado en muestreo de rechazo

# simulador de la densidad de Laplace (doble exponencial)
sim_lap<-function(n){
	# simulamos exponenciales
	x<-rexp(n)

	# luego, a algunas le cambiamos el signo y a otras no
	u<-runif(n)
	x[u<=0.5]<- -x[u<=0.5]
	return(x)
}


# comparemos la densidad objetivo y la instrumental
dlap<-function(x) 0.5*exp(-abs(x))
x<-seq(-4,4,0.01)
plot(x,dnorm(x,0,1),xlab='x',ylab='',type='l',ylim=c(0,0.7))
M<-1.3
lines(x,dlap(x),col=3)
lines(x,M*dlap(x),col=2,lwd=2)
legend('topright',c('Normal','Laplace','M*Laplace'),lty=1,col=c(1,3,2),lwd=c(1,2,2),bty='n')


# simulador de  N(0,1) basado en el metodo de rechazo
sim_norm<-function(n,mu=0,sigma=1){
	M<-1.3        # valor de la constante de normalizacion
	x<-rep(0,n)   # vector para almacenar las simulaciones
	J<-0          # contador para registrar el N total de simulaciones

	for (i in 1:n){
		# valores para comenzar el while
		U<-Inf
		Y<-0

		# contador de simulaciones
		j<-0
		while(U>dnorm(Y,0,1)/(M*0.5*exp(-abs(Y)))){
			Y<-sim_lap(1)
			U<-runif(1)
			j<-j+1
		}
		x[i]<-Y
		J<-J+j
	}
	print(J)
	return(mu+sigma*x)
}
set.seed(1234)
tiempo.sim_norm<-system.time(sim_norm(1e6))
set.seed(1234)
x<-matrix(runif(12*n),n,12);zz<-apply(x,1,sum)-6
tiempo.runif<-system.time(zz<-apply(x,1,sum)-6)
tiempo.sim_norm
tiempo.runif
set.seed(1234)
z<-sim_norm(1e6)
par(mfrow=c(1,2))
hist(z,breaks = 100,col=2)
hist(zz,breaks = 100,col=3)
qqplot(z,zz)
