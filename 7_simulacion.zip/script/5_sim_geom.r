Ni <- rgeom(10000, prob = 1/2)
Ni_table <- table(factor(Ni, 0:max(Ni)))
mean(Ni)

sim_geom<-function(n=10,p){
#  n=10
  simula<-matrix(0,n,1,byrow = TRUE)
  for (i in 1:n)
  {
    sim<-0
    u<-0
      while (u<1-p)
      {u<-runif(1)
      # print(u)
      
      
      sim<-sim+1
      # print(sim)
      message(
        paste("Me salio la uniforme",u,"y mi cantidad de sim es ", sim)
      )
      }
    simula[i]<-sim
    # print(simula[i])
  }
   return(simula)
}


geom_caseras <- sim_geom(10,0.5)
