# metodo 1 - Monte Carlo

n<-1e5
x<-rnorm(n)
hn1<-mean(x>4)
vn1<-var(x>4)/n
sqrt(vn1)

plot(seq(n),cumsum(x>4)/seq(n),type='l')
abline(h=pnorm(-4),col=2)

# metodo 2 - Muestreo de Importancia

# mismo n
x<-rexp(n)+4
hn2<-mean(dnorm(x)/exp(-(x-4)))
vn2<-var(dnorm(x)/exp(-(x-4)))/n
sqrt(vn2)

plot(seq(n),cumsum(dnorm(x)/exp(-(x-4)))/seq(n),type='l')
abline(h=pnorm(-4),col=2)

# metodo 3 - Muestreo de importancia con variables antiteticas
u1<-runif(n/2)
u2<-1-u1
x1<- -log(1-u1) + 4
x2<- -log(1-u2) + 4
x<-0.5*dnorm(x1)/exp(-(x1-4)) + 0.5*dnorm(x2)/exp(-(x2-4))
hn3<-mean(x)
vn3<-var(x)/n
sqrt(vn3)

plot(seq(n),cumsum(x)/seq(n),type='l')
abline(h=pnorm(-4),col=2)

