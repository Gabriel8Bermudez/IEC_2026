hx <-function(x) {exp(-x)}
trunca<-1-integrate(hx,0,4)$value

secuencia<-seq(0,10,0.01)
plot(secuencia[401:1001],hx(secuencia[401:1001]))

N<-1000
x<-rexp(N,1)+4
hist(x,probability = TRUE,breaks = 25)


gamma(3.1)

N<-100000
exp1<-rexp(N,1)
alfa<-3.1
hdex<-exp1**(alfa-1)
error<-(gamma(alfa)-(sum(hdex)/N))/(sum(hdex)/N)
error



https://moderndive.com/