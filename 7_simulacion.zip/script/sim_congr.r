# simulador congruencial

sim_congr<-function(n,x0,A,B,m){
	# n : cantidad de valores aleatorios
	# A, B y m : valores del simulador
 
	u<-rep(0,n)
	# valor inicial
	u[1]<-x0
	for (i in 2:n){
		u[i]<-(A*u[i-1]+B) %% m
	}
	return(u/m)
}


# simulamos valores de un BUEN simulador
n<-1000

u1<-sim_congr(n,A=1664525,B=1013904223,m=2^{32})
hist(u1)
plot(u1[-1],u1[-n])


# simulamos valores de RANDU

u2<-sim_congr(n,A=65539,B=0,m=2^{31})
hist(u2)
plot(u2[-1],u2[-n])


library(datasets)	
seed <- as.double(1)
RANDU <- function() {
    seed <<- ((2^16 + 3) * seed) %% (2^31)
    seed/(2^31)
}
for(i in 1:400) {
    U <- c(RANDU(), RANDU(), RANDU(), RANDU(), RANDU())
    print(round(U[1:3], 6))
}

# ?cual es el problema?
CL1<-embed(u1,3)%*%c(1,-6,9)
plot(CL1)

CL2<-embed(u2,3)%*%c(1,-6,9)
plot(CL2)

#https://www.r-bloggers.com/2016/02/randu-the-case-of-the-bad-rng/

devtools::source_gist("https://gist.github.com/csgillespie/0ba4bbd8da0d1264b124")


scatterplot3d::scatterplot3d(randu[,1], randu[,2], randu[,3],angle=154)
## Interactive version</p>
threejs::scatterplot3js(randu[,1], randu[,2], randu[,3])

#https://en.wikipedia.org/wiki/Mersenne_Twister#k-distribution
