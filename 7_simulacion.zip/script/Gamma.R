# Simule n realizaciones de una V.A


op <- options("warn")
options(warn = -1)
x <- sort(c(seq(-3, 4, length.out = 201), outer(0:-3, (-1:1)*1e-6, `+`)))
plot(x, gamma(x), ylim = c(-20,20), col = "red", type = "l", lwd = 2,
     main = expression(Gamma(x)))
abline(h = 0, v = -3:0, lty = 3, col = "midnightblue")
options(op)

set.seed(1234)
n<-100
alpha<-0.5
x<-rexp(n)
hdx=x**(alpha-1)
Igorro<-sum(hdx)/(1:n)
Vargorro<-(1/(n**2))*sum((hdx-Igorro)**2)
sdgorro<-sqrt(Vargorro)

GAMMA<-function(n,alpha){
  x<-rexp(n)
  hdx=x**(alpha-1)
  Igorro<-sum(hdx)/n
  Vargorro<-(1/(n**2))*sum((hdx-Igorro)**2)
  sdgorro<-sqrt(Vargorro)
  return(Integral=list(x=x,hdx=hdx,Gamma=Igorro,n=n,alpha=alpha,EE=sdgorro,LIIC=Igorro-2*sdgorro,LSIC=Igorro+2*sdgorro))
  }

(gamma1<-GAMMA(n,alpha))

set.seed(1234)

n<-10000
alpha<-4
simula<-matrix(0,n,7)

x<-rexp(n)
hdx=x**(alpha-1)

simula[,1]<-1:n
simula[,2]<-x
simula[,3]<-hdx
simula[,4]<-cumsum(hdx)
simula[,5]<-cumsum(hdx)/1:n
simula[,6]<-cumsum((hdx-simula[,5])**2)/(simula[,1]**2)
simula[,7]<-sqrt(cumsum((hdx-simula[,5])**2)/(simula[,1]**2))

plot(simula[,c(1,5)],type = "l")
abline(h=gamma(alpha),col="red")
lines(simula[,5]-2*sqrt(simula[,6]),col="green")
lines(simula[,5]+2*sqrt(simula[,6]),col="blue")


for (i in 1:n){
  simula[i,1]<-n
  simula[i,2]<-GAMMA(n,alpha)[3]
  simula[i,3]<-GAMMA(n,alpha)[7]
  simula[i,4]<-GAMMA(n,alpha)[8]
}
