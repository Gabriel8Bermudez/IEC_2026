#Stratified Sampling de STATS580

N<-10000
x<-runif(N)
y<-exp(-x**2)
summary(y)
sd(y)
s<-c(0,0.25,0.50,0.75,1)
u1<-x[x<0.25]
u2<-x[x>0.25 & x<0.5]
u3<-x[x>0.5 & x<.75]
u4<-x[x>0.75]
y1<-exp(-u1**2)
y2<-exp(-u2**2)
y3<-exp(-u3**2)
y4<-exp(-u4**2)


sigma<-sd(y1)+sd(y2)+sd(y3)+sd(y4)

sigma1<-sd(y1)/sigma
sigma2<-sd(y2)/sigma
sigma3<-sd(y3)/sigma
sigma4<-sd(y4)/sigma

Sigma<-c(sigma1,sigma2,sigma3,sigma4)
Ni<-round(N*Sigma,0)


S1<-runif(Ni[1],s[1],s[2])
S2<-runif(Ni[2],s[2],s[3])
S3<-runif(Ni[3],s[3],s[4])
S4<-runif(Ni[4],s[4],s[5])


x1<-exp(-S1**2)
x2<-exp(-S2**2)
x3<-exp(-S3**2)
x4<-exp(-S4**2)

theta1<-x1/length(x1)
theta2<-x2/length(x2)
theta3<-x3/length(x3)
theta4<-x4/length(x4)

(theta<-sum(theta1,theta2,theta3,theta4)*0.25)

var_theta<-(var(theta1)+var(theta2)+var(theta3)+var(theta4))/16
