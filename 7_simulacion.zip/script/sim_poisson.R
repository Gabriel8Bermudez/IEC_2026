# https://stackoverflow.com/questions/46892813/how-to-simulate-from-poisson-distribution-using-simulations-from-exponential-dis

lambda=2 # for example
out=sapply(1:100, function(jeje){
  u<-runif(10)
  x<--log(1-u)/lambda
  y=cumsum(x)
  length(which(y<=1))
})
mean(out)
var(out)
table(out)
n<-10
m<-10

sim_exp<-function(n,lambda =1)
{
  u<-runif(n)
  x<--log(u)/lambda
}

sim_poi<-function(n,m,lamda){
 # set.seed(1234)
  E1<-matrix(sim_exp(n*m,2),n,m)
  E2<-matrix(0,n,m)
  E3<-rep(0,m)
  for ( j in 1:m){
    suma<-cumsum(E1[,j])
    E2[,j]<-suma
    count<-length(which(E2[,j]<=1))
    E3[j]<-count
  }
return(list(Tiempos=E1,Tiempos.acumulados=E2,Recuentos=E3))  
}
n<-1000
m<-20
simula<-sim_poi(n,m,2)
plot(simula$Tiempos.acumulados[,1],col=1,type="b",ylim=c(0,max(simula$Tiempos.acumulados[,])))

for (j in 2:m){
lines(simula$Tiempos.acumulados[,j],col=j,type="b")
  
}

mean(simula$Recuentos)
var(simula$Recuentos)
table(simula$Recuentos)

set.seed(1)

p <- rpois(n=100,lambda = 2)
mean(p)
var(p)


#https://tsoo-math.github.io/ucl/poisson.html#:~:text=With%20R%20it%20is%20easy%20to%20simulate,to%20see%20the%20resulting%20Poisson%20point%20process.