sim_exp<-function(n,lambda =1)
 {
u<-runif(n)
x<--log(u)/lambda
}
x<-sim_exp(1000,4)

mean(x)

var(x)

sum(x>0.5)/1000
sim_gompz<-function(n, b=1, eta=2)
 {
u<-runif(n)
x<-(1/b)*log(1-(log(1-u))/eta)
}
x10<-sim_gompz(10,1,2)
x100<-sim_gompz(100,1,2)
x1000<-sim_gompz(1000,1,2)

summary(x10)
summary(x100)
summary(x1000)
plot(ecdf(x10),xlim=c(0,2))
lines(ecdf(x100),col=2)
lines(ecdf(x1000),col=3)
