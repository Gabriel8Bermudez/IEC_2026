install.packages("flexsurv")
library(flexsurv)
n<-1000
X<-rgompertz(n, shape = 1, rate = 1)
summary(x)
plot(ecdf(x))
?rgompertz
x<-seq(0,2.5,0.0025)
x<-x[1:1000]

plot(ecdf(X))

lines(sort(X),pgompertz(sort(X), shape=1, rate = 1, lower.tail = TRUE, log.p = FALSE),col=2)
plot(x,sort(X))

plot(x,dgompertz(x, shape=1, rate = 1, log = FALSE))


sim_congr<-function(n,x0,A,B,m){
  # n : cantidad de valores aleatorios
  # A, B y m : valores del simulador
  
  u<-rep(0,n)
  # valor inicial
  u[1]<-x0
  for (i in 2:n){
    u[i]<-(A*u[i-1]+B) %% m
  }
  return(u/m)
}



######################
#Para poder  simular la gompertz day que despejar la X en función de la u

