#################################################
#	Aplicacion 1 - verosimilitud gaussiana	#
#################################################

mu<-40
sigma<-6

n<-100
datos<-rnorm(n,mean=mu,sd=sigma)


vg<-function(parms){
	...
}

dvg<-function(parms) {
	...
}

ascenso(vg,dvg,c(30,3))
bfgs(vg,dvg,c(30,3))
dfp(vg,dvg,c(30,3))
sr1(vg,dvg,c(30,3))


###########################################
#	Aplicacion 2 - minimos cuadrados	#
###########################################

data(mtcars)
sc<-function(params){
	...
}

dsc<-function(params) {
	...
}

ascenso(sc,dsc,rep(0,4))
bfgs(sc,dsc,rep(0,4))
dfp(sc,dsc,rep(0,4))
sr1(sc,dsc,rep(0,4))

# comparar con
summary(lm(mpg~wt+qsec+am,data=mtcars))$coef