# verosimilitud gaussiana

mu<-40
sigma<-6

n<-100
datos<-rnorm(n,mean=mu,sd=sigma)


vg<-function(parms){
	L<-0
	n<-length(datos)
	mu<-parms[1]
	#sigma<-exp(parms[2])
	sigma<-parms[2]
	for (i in 1:n) L<-L-0.5*log(2*pi)-0.5*log(sigma)-0.5*((datos[i]-mu)/sigma)^2
	return(L)
}

dvg<-function(parms) {
	L<-c(0,0)
	n<-length(datos)
	mu<-parms[1]
	#sigma<-exp(parms[2])
	sigma<-parms[2]
	for (i in 1:n) {
		L[1]<-L[1]+(datos[i]-mu)/(sigma^2)
		L[2]<-L[2]+((datos[i]-mu)^2)/(sigma^3) - 1/(2*sigma)
	}
	return(L)
}

ascenso(vg,dvg,c(30,3))
bfgs(vg,dvg,c(30,3))
dfp(vg,dvg,c(30,3))
sr1(vg,dvg,c(30,3))


# minimos cuadrados o absolutos

data(mtcars)
sc<-function(params){
	n <-nrow(mtcars)
	y <- mtcars$mpg
	x <- mtcars[,c('wt','qsec','am')]
	x <- as.matrix(cbind(1,x))
	fx<- sum((y-x%*%params)^2)
	return(-fx)
}

dsc<-function(params) grad(sc,params)

dsc<-function(params) {
	n  <-nrow(mtcars)
	y  <- mtcars$mpg
	x  <- mtcars[,c('wt','qsec','am')]
	x  <- as.matrix(cbind(1,x))
	grad<- 2*c(sum(y-x%*%params),sum(x[,2]*(y-x%*%params)),sum(x[,3]*(y-x%*%params)),sum(x[,4]*(y-x%*%params)))
	return(grad)
}

ascenso(sc,dsc,rep(0,4))
bfgs(sc,dsc,rep(0,4))
dfp(sc,dsc,rep(0,4))
sr1(sc,dsc,rep(0,4))

# comparar con
summary(lm(mpg~wt+qsec+am,data=mtcars))$coef

