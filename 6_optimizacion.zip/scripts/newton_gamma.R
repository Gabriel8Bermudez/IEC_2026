# Code spuRs/resources/scripts/newton_gamma.r

newton <- function(f3, x0, tol = 1e-9, n.max = 100) {
    # Newton's method for optimisation, starting at x0
    # f3 is a function that given x returns the vector
    # (f(x), f'(x), f''(x)), for some f

    x <- x0
    f3.x <- f3(x)
    n <- 0
    while ((abs(f3.x[2]) > tol) & (n < n.max)) {
        x <- x - f3.x[2]/f3.x[3]
        f3.x <- f3(x)
        n <- n + 1
    }
    if (n == n.max) {
        cat('newton failed to converge\n')
    } else {
        return(list(xmax = x,n = n))
    }
}

gamma.2.3 <- function(x) {
    # gamma(2,3) density
    if (x < 0) return(c(0, 0, 0))
    if (x == 0) return(c(0, 0, NaN))
    y <- exp(-2*x)
    return(c(4*x^2*y, 8*x*(1-x)*y, 8*(2*x^2-4*x+1)*y))
}


fx = function(x) {
  y <- exp(-2*x)
  
  4*x^2*y
}

f1x = function(x) {
  y <- exp(-2*x)
  
  8*x*(1-x)*y
  
}

f2x = function(x) {
  y <- exp(-2*x)
  
  8*(2*x^2-4*x+1)*y
  
}


suc = function(x0) {
  x0 - f1x(x0)/f2x(x0)
}
x = 1:100
y = gamma_2_3(x)
plot(x,y)



newton(gamma.2.3, 0.35)
newton(gamma.2.3, 0.5)
newton(gamma.2.3, 0.75)

res = sapply(X = seq(0,1,0.001),FUN = function(x) {newton(gamma.2.3,x)})

gamma_2_3<-function(x)4*x^2*exp(-2*x)
gamma_2_3(1)
curve(gamma_2_3,0,6)
x<-seq(0,6,0.01)
fx<-gamma_2_3(x)
plot(x,fx,type="l")
abline(v=1,col=2)
abline(h=gamma_2_3(1),col=3)
