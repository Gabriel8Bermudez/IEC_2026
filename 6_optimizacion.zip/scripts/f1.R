f1<-function(x){
	x1<-x[1]
	x2<-x[2]
	sin(0.5*x1^2-0.25*x2^2)*cos(2*x1-exp(x2))
}

x1<-seq(-0.5,3,0.01)
x2<-seq(-0.5,2,0.01)

nf<-length(x1)
nc<-length(x2)

z<-matrix(0,nrow=nf,ncol=nc)
for (i in 1:nf) {
	for(j in 1:nc) {
		z[i,j]<-f1(c(x1[i],x2[j])) 
	}
}

# curvas de nivel
colores <- c('#fff7fb','#ece7f2','#d0d1e6','#a6bddb','#74a9cf','#3690c0','#0570b0','#045a8d','#023858')
titulo  <- bquote('Curvas de nivel de'~f(x[1],x[2]))

image(x1,x2,z,xlab=expression(x[1]),ylab=expression(x[2]),col=colores,main=titulo)
contour(x1,x2,z,xlab=expression(x[1]),ylab=expression(x[2]),nlevels=50,main=titulo)

# graficos tridimensionales
x11(30,20)
par(mfrow=c(3,4),mar=c(1,1,1,1))
for (angulo in seq(30,360,length=12)) persp(x1,x2,z,theta=angulo,col = "lightblue")


