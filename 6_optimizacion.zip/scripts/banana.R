banana<-function(x){
	x1<-x[1]
	x2<-x[2]
	return(-100*(x2-x1^2)^2-(1-x1)^2)
}

dbanana<-function(x){
	x1<-x[1]
	x2<-x[2]
	dx1<-400*x1^3+2*x1-400*x1*x2-2
	dx2<-200*(x2-x1^2)
	return(-c(dx1,dx2))
}

ddbanana<-function(x){
	x1<-x[1]
	x2<-x[2]
	d2x1<-1200*x1^2+2-400*x2
	d2x2<- 200
	dx1x2<- -400*x1
	return(-matrix(c(d2x1,dx1x2,dx1x2,d2x2),2,2))
}

x1<-seq(-2,2,0.01)
x2<-seq(-2,2,0.01)

nf<-length(x1)
nc<-length(x2)

z<-matrix(0,nrow=nf,ncol=nc)
for (i in 1:nf) {
	for(j in 1:nc) {
		z[i,j]<-banana(c(x1[i],x2[j])) 
	}
}

# curvas de nivel
titulo  <- bquote('Curvas de nivel de'~f(x[1],x[2]))

contour(x1,x2,z,xlab=expression(x[1]),ylab=expression(x[2]),nlevels=50,main=titulo)




ascenso(banana,dbanana,c(1.2,1.2))
tiempo.1000<-system.time(ascenso(banana,dbanana,c(1.2,1.2)))
tiempo.100
# hay que aumentar las iteraciones
ascenso(banana,dbanana,c(1.2,1.2),maxiter=50000)

tiempo.50000<-ascenso(banana,dbanana,c(1.2,1.2),maxiter=50000)

# el otro punto de arranque
tiempo.50000b<-ascenso(banana,dbanana,c(-1.2,1),maxiter=50000)
