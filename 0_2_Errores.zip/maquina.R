.Machine
noquote(unlist(format(.Machine)))
.Platform
maquina1<-.Machine
names(maquina1)
plataforma<-.Platform
names(plataforma)

round(.5 + -2:4) # IEEE / IEC rounding: -2  0  0  2  2  4  4
## (this is *good* behaviour -- do *NOT* report it as bug !)

( x1 <- seq(-2, 4, by = .5) )
round(x1,3) #-- IEEE / IEC rounding !
x1[trunc(x1) != floor(x1)]
x1[round(x1) != floor(x1 + .5)]
(non.int <- ceiling(x1) != floor(x1))

x2 <- pi * 100^(-1:3)
round(x2, 3)
signif(x2, 3)

suma<-1
suma<-suma+.Machine$double.eps
suma
signif(suma,20)
2*.Machine$double.eps
1==1+.Machine$double.eps
