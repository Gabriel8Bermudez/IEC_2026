exponente<-seq(-2,2,1)
exponente


mantisa<-seq(0,0.99,0.01)
mantisa
mantisa*10**exponente
mantisa*10**exponente[1]
RPF<-c(mantisa*10**exponente[1],mantisa*10**exponente[2],mantisa*10**exponente[3],mantisa*10**exponente[4],mantisa*10**exponente[5])

summary(RPF)
hist(RPF)
plot(ecdf(RPF))
plot(density(RPF))
sort(RPF)
